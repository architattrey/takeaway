<?php

namespace Cloudinary\Api;

class AlreadyExists extends Error
{
}
