<?php

namespace Cloudinary\Api;

class NotAllowed extends Error
{
}
