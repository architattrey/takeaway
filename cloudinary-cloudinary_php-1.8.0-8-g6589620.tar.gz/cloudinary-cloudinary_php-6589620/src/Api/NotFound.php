<?php

namespace Cloudinary\Api;

class NotFound extends Error
{
}
