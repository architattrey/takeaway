<?php

namespace Cloudinary\Api;

class AuthorizationRequired extends Error
{
}
