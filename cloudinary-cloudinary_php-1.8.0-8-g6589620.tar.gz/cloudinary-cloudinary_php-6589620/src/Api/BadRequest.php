<?php

namespace Cloudinary\Api;

class BadRequest extends Error
{
}
