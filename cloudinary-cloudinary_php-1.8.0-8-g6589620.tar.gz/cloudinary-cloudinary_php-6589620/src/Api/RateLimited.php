<?php

namespace Cloudinary\Api;

class RateLimited extends Error
{
}
